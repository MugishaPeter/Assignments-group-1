classdef DampedDrivenOscillator < DifferentialNumericalmethodsparent
    % Oscillator solver
    
    properties
        dt = 0.01;
        initial_conditions = [0, 0];
    end
    
    methods
        function obj = DampedDrivenOscillator(func, lower_limit, upper_limit, num_steps, dt, initial_conditions)
            % Calling the parent constructor
            obj@DifferentialNumericalmethodsparent(func, lower_limit, upper_limit, num_steps);
            
            if nargin >= 5
                obj.dt = dt;
            end
            if nargin >= 6
                obj.initial_conditions = initial_conditions;
            end
        end
        
        function result = solve(obj)
            % Euler method application for oscillator
            time_points = linspace(obj.lower_limit, obj.upper_limit, obj.num_steps);
            solution = zeros(1, obj.num_steps);
            
            x = obj.initial_conditions(1);
            xd = obj.initial_conditions(2);
            solution(1) = x;
            
            for i = 2:obj.num_steps
                t = time_points(i-1);
                % Using the function to compute acceleration
                xdd = obj.func(t, x, xd);
                xd = xd + xdd * obj.dt;
                x = x + xd * obj.dt;
                solution(i) = x;
            end
            
            result.time = time_points;
            result.solution = solution;
            result.velocity = xd;
        end
        
        function display_result(obj, result)
            fprintf('\n=== Damped Driven Oscillator Results ===\n');
            fprintf('Time range: %.2f to %.2f seconds\n', obj.lower_limit, obj.upper_limit);
            fprintf('Time step: %.4f\n', obj.dt);
            fprintf('Final displacement: %.6f\n', result.solution(end));
            
            figure;
            plot(result.time, result.solution, 'b-', 'LineWidth', 2);
            xlabel('Time (s)');
            ylabel('Displacement');
            title('Damped Driven Oscillator');
            grid on;
        end
    end
end