classdef DifferentialFixedPoint < DifferentialNumericalmethodsparent
    % Fixed point iteration for differential equations
    
    properties
        max_iterations
        tolerance
    end
    
    methods
        function obj = DifferentialFixedPoint(func, lower_limit, upper_limit,...
                num_steps, max_iterations, tolerance)
            % Call parent constructor
            obj@DifferentialNumericalmethodsparent(func, lower_limit, upper_limit, num_steps);
            
            if nargin < 5
                obj.max_iterations = 1000;
            else
                obj.max_iterations = max_iterations;
            end
            
            if nargin < 6
                obj.tolerance = 1e-6;
            else
                obj.tolerance = tolerance;
            end
        end
        
        function result = solve(obj)
            % Simple fixed point iteration
            x_guess = (obj.lower_limit + obj.upper_limit) / 2; % Start from middle
            iteration_count = 0;
            
            for k = 1:obj.max_iterations
                x_new = obj.func(x_guess);
                error = abs(x_new - x_guess);
                iteration_count = k;
                
                if error < obj.tolerance
                    break;
                end
                
                x_guess = x_new;
            end
            
            result.solution = x_new;
            result.iterations = iteration_count;
            result.final_error = error;
            result.converged = (error < obj.tolerance);
        end
        
        function display_result(obj, result)
            fprintf('\n=== Fixed Point Method Results ===\n');
            fprintf('Initial guess: %.4f\n', (obj.lower_limit + obj.upper_limit)/2);
            fprintf('Final solution: %.6f\n', result.solution);
            fprintf('Iterations: %d\n', result.iterations);
            fprintf('Final error: %e\n', result.final_error);
            fprintf('Converged: %s\n', string(result.converged));
            
            % Simple visualization
            x_test = linspace(obj.lower_limit, obj.upper_limit, 100);
            y_test = arrayfun(obj.func, x_test);
            
            figure;
            plot(x_test, y_test, 'b-', 'LineWidth', 2);
            hold on;
            plot(x_test, x_test, 'r--', 'LineWidth', 1);
            plot(result.solution, result.solution, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
            legend('Function y = f(x)', 'Line y = x', 'Fixed Point', 'Location', 'best');
            xlabel('x');
            ylabel('f(x)');
            title('Fixed Point Iteration');
            grid on;
        end
    end
end