classdef TrapezoidalIntegration < NumericalIntegration
    methods
        function obj = TrapezoidalIntegration(a,b,n)
            obj@NumericalIntegration(a,b,n);
        end

        function result = integrate(obj, f)
            h = (obj.b - obj.a) / obj.n;
            x = obj.a:h:obj.b;
            y = f(x);
            result = (h/2) * (y(1) + 2 * sum(y(2:end-1)) + y(end));
        end
    end
end
